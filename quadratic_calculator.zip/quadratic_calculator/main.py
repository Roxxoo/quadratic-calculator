import math
# def decision(choice):
#     return {
#            'a': a+b,
#            'b': a-b,
#            'c': (a*b),
#            'd': (a/b),
#            }.get(choice,"Invalid")

def quadratic_equation(a,b,c):

      soln1 = float(-b + (math.sqrt((b**2 - (4*(a*c)))))) / 2 * a
      soln2 = float(-b - (math.sqrt((b**2 - (4*(a*c)))))) / 2 * a
      answers = [soln1, soln2]
      return answers


choice = None

while (choice != 'a') and (choice != 'b'):
    choice = str.lower(input("A (quadratic equation) or B: "))


if choice == 'a':
    a = int(input("Enter value of A: " ))
    b = int(input("Enter value of B: " ))
    c = int(input("Enter value of C: " ))
    answers = []
    answers = quadratic_equation(a,b,c)
    print("Answer of b + root: ", answers[0])
    print("Answer of b - root: ", answers[1])

else:
    choice = None

    while (choice != 'a') and (choice != 'b') and choice != 'c' and choice != 'd':
        choice = str.lower(input("A. Add\nB. Subtract\nC. Multiply\nD. Divide\nChoice:"))

    print("You have chosen option: ", choice)
    a = int(input("Enter value of A: "))
    b = int(input("Enter value of B: "))

    # print(decision(choice))

    if choice == 'a':
        print("Sum = " , a + b)

    elif choice == 'b':
        print("Difference = ", a - b)

    elif choice == 'c':
        print("Product = ", a * b)

    else:
        print("Quotient = ", a/b)
